
  # ChambaMax

  This is a code bundle for ChambaMax. The original project is available at https://www.figma.com/design/2e5EODVZCwvCYUSprJKxoh/ChambaMax.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  